# ByeBlocker

The only TRULY UNBLOCKABLE proxy that works on Netlify, codepen, playcode, as a bookmarklet, never shows up in your history, and MORE! (The ONLY unblocker that works on static hosts)

Name inspired by Zek-c

This can run as a bookmarklet.

[The Subreddit](https://www.reddit.com/r/swordstuff/)

[Discord Server](https://discord.gg/BMxe6D9CKv)

## How to use without bookmarklets

1. Go to Netlify/Codepen/Render/Other 

2. Deploy

3. Annoy school admins

<img width="677" alt="image" src="https://github.com/Tacogamerman/ByeBlocker/assets/119009502/aebfcb59-4fc1-4d8b-bb19-527d16176458">
